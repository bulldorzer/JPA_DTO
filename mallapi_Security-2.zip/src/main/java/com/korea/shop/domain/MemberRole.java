package com.korea.shop.domain;

public enum MemberRole {
    USER, MANAGER, ADMIN;
}
